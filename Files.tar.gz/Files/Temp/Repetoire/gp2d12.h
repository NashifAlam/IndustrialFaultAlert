#include "types.h"
u8 ReadRangeGP2D12(u8 chNo);

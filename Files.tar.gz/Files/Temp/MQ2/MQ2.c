int smokeSensorReading()
{
	return 1;
}

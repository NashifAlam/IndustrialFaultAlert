//lm35.h
u8 ReadTempLM35(u8 chNo);

//adc.h
#include "types.h"
void Init_ADC(void);
f32  Read_ADC(u32 chNo);

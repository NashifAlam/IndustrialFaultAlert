//seg_defines.h
#define SEG 8  //p0.8 to p0.15
#define CA1 16 //p0.16
#define CA2 17 //p0.17

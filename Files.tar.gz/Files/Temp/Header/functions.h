
void Alert(void);
void LCDStart(void);
void checkPassword(void);

//delay.h
void delay_us(unsigned int dlyUS);
void delay_ms(unsigned int dlyMS);
void delay_s(unsigned int dlyS);

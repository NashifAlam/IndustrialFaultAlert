#include "types.h"

void BlinkRedLED(void);
void RedLED(short int);
void GreenLED(short int);

//seg.h
#include "types.h"
void Init_7segs(void);
void disp_2_mux_segs(u8 );
void dispf_2_mux_segs(f32 );

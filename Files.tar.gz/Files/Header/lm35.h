//lm35.h
f32 ReadTempLM35(u8 chNo);

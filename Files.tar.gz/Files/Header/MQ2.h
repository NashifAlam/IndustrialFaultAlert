
void init_MQ2(void);
int smokeSensorReading(void);

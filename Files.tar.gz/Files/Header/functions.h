
void Alert(unsigned int);
void checkPassword(void);
void changeThreshold(void);
void changePassword(void);
void irr(void);
